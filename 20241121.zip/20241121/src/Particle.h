#pragma once

#include "ofMain.h"

class Particle {
public:
    glm::vec3 position;
    glm::vec3 velocity;
    ofColor color;
};
